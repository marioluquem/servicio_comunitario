<?php $__env->startSection('includesHead'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- jQuery UI -->
<?php echo Html::style('https://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css'); ?>

<!-- Bootstrap -->
<?php echo Html::style('css/bootstrap.min.css'); ?>

<!-- styles -->
<?php echo Html::style('css/styles.css'); ?>

<?php echo Html::style('css/estilos.css'); ?>

<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-10">
    <div class="content-box-large">
        <div class="panel-title col-md-offset-4"><h2>Nuevo Equipo</h2></div>
        <div class="panel-body">
            <div class="col-md-8 col-md-offset-1">
                <div class="row">
                    <div class="box">
                        <div class="content-wrap">
                            <form action="createTeam" method="post" enctype="multipart/form-data" id="formulario_equipo">
                                <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                                <div class="form-group">

                                    <label class="control-label" style="font-size:14px;">Universidad:</label>
                                    <select name="universidad" id="universidad" class="form-control">
                                        <?php foreach($univ as $univ): ?>
                                        <option value="<?php echo e($univ->acronimo); ?>"><?php echo e($univ->acronimo); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <br>
                                    <label class="control-label" style="font-size:14px;">Disciplina:</label>
                                    <select name="disciplina" id="disciplina" class="form-control">
                                        <?php foreach($disciplinaNombre as $disciplina): ?>
                                            <option value="<?php echo e($disciplina->id); ?>"><?php echo e($disciplina->nombre_disciplina); ?></option>
                                            <?php endforeach; ?>
                                    </select>
                                    <br>
                                    <select name="modalidad" id="modalidad" class="form-control">
                                        <?php foreach($disciplinaModalidad as $disciplina): ?>
                                            <option value="<?php echo e($disciplina->modalidad); ?>"><?php echo e($disciplina->modalidad); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <br>
                                    <label class="control-label" style="font-size:14px;">Nombre:</label>
                                    <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre...">
                                    <br>

                                    <input type="submit" class="btn btn-primary" value="Crear Equipo" >

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('includes'); ?>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<?php echo Html::script('https://code.jquery.com/jquery.js'); ?>

<!-- jQuery UI -->
<?php echo Html::script('https://code.jquery.com/ui/1.10.3/jquery-ui.js'); ?>

<!-- Include all compiled plugins (below), or include individual files as needed -->
<?php echo Html::script('js/bootstrap.min.js'); ?>

<?php echo Html::script('js/custom.js'); ?>

<script src="js/validacion_formulario.js"></script>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>