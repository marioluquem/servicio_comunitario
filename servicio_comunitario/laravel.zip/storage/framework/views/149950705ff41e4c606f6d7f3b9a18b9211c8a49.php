<?php $__env->startSection('includesHead'); ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- jQuery UI -->
    <link href="https://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css" rel="stylesheet" media="screen">

    <!-- Bootstrap -->
    <!--suppress HtmlUnknownTarget, HtmlUnknownTarget -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <!--suppress HtmlUnknownTarget, HtmlUnknownTarget -->
    <link href="../css/styles.css" rel="stylesheet">
    <?php echo Html::style('css/estilos.css'); ?>

    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-10">
        <div class="row">
            <div class="content-box-large">
                <div class="panel-heading">
                    <div class="panel-title"><h2>Detalle Equipo</h2></div>
                    <div class="panel-options">
                        <a href="#" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>
                        <a href="#" data-rel="reload"><i class="glyphicon glyphicon-cog"></i></a>
                    </div>
                </div>
                <div class="panel-body">
                    <?php foreach($equipo as $equipo): ?>
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                            <thead>
                            <tr>
                                <th>Editar</th>
                                <th>Representante</th>
                                <th>Nombre</th>
                                <th>Eliminar</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if($jugadores != null): ?>
                                <?php foreach($jugadores as $jugador): ?>
                                    <tr class="odd gradeX" id="<?php echo e($jugador->cedula); ?>" >
                                        <td><a href="<?php echo e(route('detailUser', array('id' => $jugador->cedula))); ?>"><button class="btn btn-primary"><i class="glyphicon glyphicon-pencil"></i> Edit</button></a></td>
                                        <td class="center"><input type="radio" id="radio" name="radio" class="radio" value="<?php echo e($jugador->cedula); ?>" onclick="evaluarRepresentante(<?php echo e($jugador->cedula); ?>)"></td>
                                        <td class="center"><?php echo e($jugador->primer_nombre.' '.$jugador->primer_apellido.' '.$jugador->segundo_apellido); ?></td>
                                        <td><a href="<?php echo e(route('deleteUserFromTeam', array('idUser' => $jugador->cedula, 'nombreEquipo' => $equipo->nombre_equipo))); ?>"  id="dialog"><button class="btn btn-danger"><i class="glyphicon glyphicon-remove"></i> Delete</button></a></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        <br>
                    <?php echo Form::open(array('url'=>'updateTeam', 'method'=>'post','id'=>'formulario_update')); ?>

                        <input type="hidden" name="representante" id="representante" value="0"/>
                        <input type="hidden" name="nombreEquipo" id="nombreEquipo" value="<?php echo e($equipo->nombre_equipo); ?>"/>
                        <div class="content-wrap">
                            <div class="form-group">
                                <label for="">Nombre</label>
                                <input class="form-control" type="text" placeholder="Nombre..." name="nombre_equipo" value="<?php echo e($equipo->nombre_equipo); ?>">
                                <br>
                                <label for="">Disciplina</label>
                                <input class="form-control" type="text" placeholder="Disciplina..." name="nombre_disciplina" value="<?php echo e($equipo->nombre_disciplina); ?>">
                                <br>
                                <label for="">Modalidad</label>
                                <input class="form-control" type="text" placeholder="Modalidad..." name="modalidad" value="<?php echo e($equipo->modalidad); ?>">
                                <br>
                                <label for="">Universidad</label>
                                <input class="form-control" type="text" placeholder="Universidad..." name="acronimo" value="<?php echo e($equipo->acronimo); ?>">
                                <br>
                                <label for="">Insertar nuevos jugadores en el equipo</label>
                                <input class="form-control" type="text" placeholder="Inserte cédula..." name="cedulaNuevoUsuario1" value="">
                                <br>
                                <input class="form-control" type="text" placeholder="Inserte cédula..." name="cedulaNuevoUsuario2" value="">
                                <br>
                                <input class="form-control" type="text" placeholder="Inserte cédula..." name="cedulaNuevoUsuario3" value="">
                                <br>
                                <input class="form-control" type="text" placeholder="Inserte cédula..." name="cedulaNuevoUsuario4" value="">
                                <br>
                                <input class="form-control" type="text" placeholder="Inserte cédula..." name="cedulaNuevoUsuario5" value="">
                                <br>
                                <input type="submit" class="btn btn-primary" value="Guardar Cambios en Equipo" >
                            </div>
                        </div>

                    <?php echo Form::close(); ?>

                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<script>
    function evaluarRepresentante(cedula){
        $('#representante').val(cedula);
        //alert($('#representante').val());
    }
</script>
<?php $__env->startSection('includes'); ?>
    <link href="../vendors/datatables/dataTables.bootstrap.css" rel="stylesheet" media="screen">

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <!--suppress HtmlUnknownTarget, HtmlUnknownTarget -->
    <script src="../js/bootstrap.min.js"></script>

    <!--suppress HtmlUnknownTarget, HtmlUnknownTarget, HtmlUnknownTarget, HtmlUnknownTarget -->
    <script src="../vendors/datatables/js/jquery.dataTables.min.js"></script>

    <!--suppress HtmlUnknownTarget, HtmlUnknownTarget, HtmlUnknownTarget -->
    <script src="../vendors/datatables/dataTables.bootstrap.js"></script>

    <!--suppress HtmlUnknownTarget, HtmlUnknownTarget -->
    <script src="../js/custom.js"></script>
    <!--suppress HtmlUnknownTarget, HtmlUnknownTarget -->
    <script src="../js/tables.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>