<?php $__env->startSection('includesHead'); ?>
   <?php echo Html::style('css/bootstrap.min.css'); ?>

   <?php echo Html::style('css/style.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <fieldset>
        <legend>Inicio de Sesión</legend>
        <?php echo Form::open(['route'=>'usuario.store','method'=>'post']); ?>

           <div class="Form-group">
               <?php echo Form::label('usuario: '); ?> 
               <?php echo Form::text('user',null,['class'=>'form-control', 'placeholder'=>'ingresa el usuario']); ?>

               
               <?php echo Form::label('password: '); ?> 
               <?php echo Form::password('password',['class'=>'form-control','placeholder'=>'ingresa el password']); ?>

               
               <?php echo Form::submit('iniciar sesion', ['class'=>'btn btn-default']); ?>  
            </div>
        <?php echo Form::close(); ?>

    </fieldset>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>