<?php $__env->startSection('includesHead'); ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- jQuery UI -->
    <link href="https://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css" rel="stylesheet" media="screen">

    <!-- Bootstrap -->
    <!--suppress HtmlUnknownTarget, HtmlUnknownTarget -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <!--suppress HtmlUnknownTarget, HtmlUnknownTarget -->
    <link href="../css/styles.css" rel="stylesheet">
    <?php echo Html::style('css/estilos.css'); ?>

    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-10">
        <div class="row">
                <div class="content-box-large">
                    <div class="panel-heading">
                        <div class="panel-title"><h2>Detalle Usuario</h2></div>
                        <div class="panel-options">
                            <a href="#" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>
                            <a href="#" data-rel="reload"><i class="glyphicon glyphicon-cog"></i></a>
                        </div>
                    </div>
                    <div class="panel-body">
                            <?php echo Form::open(array('url'=>'updateUser', 'method'=>'post','id'=>'formulario_update')); ?>

                            <?php foreach($data as $user): ?>
                                <div class="content-wrap">
                                <div class="form-group">
                                    <label for="">Cédula</label>
                                    <input class="form-control" type="number" placeholder="cédula" name="cedula" value="<?php echo e($user->cedula); ?>">
                                    <br>
                                    <label for="">Primer Nombre</label>
                                    <input class="form-control" type="text" placeholder="primer nombre" name="primer_nombre" value="<?php echo e($user->primer_nombre); ?>">
                                    <br>
                                    <label for="">Primer Apellido</label>
                                    <input class="form-control" type="text" placeholder="primer apellido" name="primer_apellido" value="<?php echo e($user->primer_apellido); ?>">
                                    <br>
                                    <label for="">Rol</label>
                                    <select name="rol" class="form-control">
                                        <?php if($user->fk_rol == 1): ?>
                                            <option value="1" selected>Administrador</option>
                                        <?php else: ?>
                                            <option value="1" selected>Administrador</option>
                                        <?php endif; ?>
                                        <?php if($user->fk_rol == 2): ?>
                                            <option value="2" selected>Director</option>
                                        <?php else: ?>
                                            <option value="2" >Director</option>
                                        <?php endif; ?>
                                        <?php if($user->fk_rol == 3): ?>
                                            <option value="3" selected>Usuario común</option>
                                        <?php else: ?>
                                            <option value="3">Usuario común</option>
                                        <?php endif; ?>
                                    </select>
                                    <br>
                                    <label for="">Universidad</label>
                                            <?php if($user->acronimo != null ): ?>
                                                <input class="form-control" type="text" value="<?php echo e($user->acronimo); ?>" disabled/>
                                            <?php else: ?>
                                                <input class="form-control" type="text" value="No tiene Universidad" disabled/>
                                            <?php endif; ?>
                                   <br>
                                    <label for="">Correo</label>
                                    <input class="form-control" type="email" placeholder="correo" name="correo" value="<?php echo e($user->correo); ?>">
                                    <br>
                                    <?php echo Form::label('Género: ', null, array('style'=>'font-size:14px;')); ?>

                                    <?php if( $user->sexo == 'm'): ?>
                                        <?php echo Form::label('M', null, array('style'=>'font-size:14px;')); ?>  <input type="radio" name="sexo" value="m" class="genero"  style ="margin-left: 4px; margin-right: 4px;" checked>
                                        <?php echo Form::label('F', null, array('style'=>'font-size:14px;')); ?>  <input type="radio" name="sexo" value="f" class="genero"  style ="margin-left: 4px; margin-right: 4px;" >
                                    <?php elseif($user->sexo == 'f'): ?>
                                        <?php echo Form::label('M', null, array('style'=>'font-size:14px;')); ?>  <input type="radio" name="sexo" value="m" class="genero"  style ="margin-left: 4px; margin-right: 4px;" >
                                        <?php echo Form::label('F', null, array('style'=>'font-size:14px;')); ?>  <input type="radio" name="sexo" value="f" class="genero"  style ="margin-left: 4px; margin-right: 4px;" checked>
                                     <?php endif; ?>
                                    <br>
                                    <input type="submit" class="btn btn-primary" value="Guardar Cambios" onclick="javascript:validar_formulario()">
                                </div>
                                </div>
                            <?php endforeach; ?>
                            <?php echo Form::close(); ?>

                    </div>
                </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('includes'); ?>
            <link href="../vendors/datatables/dataTables.bootstrap.css" rel="stylesheet" media="screen">

            <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
            <script src="https://code.jquery.com/jquery.js"></script>
            <!-- jQuery UI -->
            <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
            <!-- Include all compiled plugins (below), or include individual files as needed -->
            <!--suppress HtmlUnknownTarget, HtmlUnknownTarget -->
            <script src="../js/bootstrap.min.js"></script>

            <!--suppress HtmlUnknownTarget, HtmlUnknownTarget, HtmlUnknownTarget, HtmlUnknownTarget -->
            <script src="../vendors/datatables/js/jquery.dataTables.min.js"></script>

            <!--suppress HtmlUnknownTarget, HtmlUnknownTarget, HtmlUnknownTarget -->
            <script src="../vendors/datatables/dataTables.bootstrap.js"></script>

            <!--suppress HtmlUnknownTarget, HtmlUnknownTarget -->
            <script src="../js/custom.js"></script>
            <!--suppress HtmlUnknownTarget, HtmlUnknownTarget -->
            <script src="../js/tables.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>