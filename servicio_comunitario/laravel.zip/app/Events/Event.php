<?php

namespace servicio_comunitario\Events;

abstract class Event
{
    //
}
